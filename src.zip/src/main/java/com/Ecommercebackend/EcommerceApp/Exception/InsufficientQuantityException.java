package com.Ecommercebackend.EcommerceApp.Exception;

public class InsufficientQuantityException extends Exception{

    public InsufficientQuantityException(String message){
        super(message);
    }
}
