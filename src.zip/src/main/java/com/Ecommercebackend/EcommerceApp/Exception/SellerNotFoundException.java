package com.Ecommercebackend.EcommerceApp.Exception;

public class SellerNotFoundException extends Exception{

    public SellerNotFoundException(String message){
        super(message);
    }

}
