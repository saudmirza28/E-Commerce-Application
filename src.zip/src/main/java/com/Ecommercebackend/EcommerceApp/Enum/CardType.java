package com.Ecommercebackend.EcommerceApp.Enum;

public enum CardType {

    VISA,
    MASTERCARD,
    RUPAY
}
