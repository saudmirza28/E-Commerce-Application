package com.Ecommercebackend.EcommerceApp.Enum;

public enum ProductStatus {

    AVAILABLE,
    OUT_OF_STOCK
}
