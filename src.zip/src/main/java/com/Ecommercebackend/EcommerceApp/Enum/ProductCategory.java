package com.Ecommercebackend.EcommerceApp.Enum;

public enum ProductCategory {
    SPORTS,
    FASHION,
    ELECTRONICS
}
